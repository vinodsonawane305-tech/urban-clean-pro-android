Urban Clean Pro Android Project

This project is prepared for Code on the Go.

Open the ucp_android folder in Code on the Go using Open a saved project > Open from folder.

The project uses Android Gradle Plugin 8.11.0, Java 17 compatibility, and Gradle 8.13.
